from _Epistasis_functions import *

folder = '../Epistasis/Detailed data - epistasis change'

# All variants
print('Checking all variants')
data = {
    'mut A bg':[],
    'mut A result':[],
    'mut A locus':[],
    
    'mut B bg':[],
    'mut B result':[],
    'mut B locus':[],

    'epistasis on bg':[],

    'mut X bg':[],
    'mut X result':[],
    'mut X locus':[],

    'epistasis on mut':[],

    'Count':[]
    }

series = {}

errors = set()
count = 0
total_variants = 4**9
for variant in get_variants(9):
    count += 1
    if variant not in fitness_data.keys():
        continue

    for mut_pair in generate_mutations(2):
        mut_A = mut_pair[0]
        mut_B = mut_pair[1]

        if not (mutation_feasibility(variant,mut_A) and \
                mutation_feasibility(variant,mut_B)):
            continue

        try:
            mut_bA = get_mutant(variant,mut_A)
            mut_bB = get_mutant(variant,mut_B)
            be_nature = check_epistasis_nature(variant,mut_pair)['Nature']
            
        except KeyError:
            continue

        for mutation in generate_mutations(1):
            mut_X = mutation[0]

            if mut_X[1] in [mut_A[1],mut_B[1]] or \
               not mutation_feasibility(variant,mut_X):
                continue

            try:
                m = get_mutant(variant,mut_X)

                me_nature = check_epistasis_nature(m,mut_pair)['Nature']
                
            except KeyError:
                continue

            sub_series = (
                
                variant[mut_A[1]],
                mut_A[0],
                mut_A[1]+1,

                variant[mut_B[1]],
                mut_B[0],
                mut_B[1]+1,

                be_nature,

                variant[mut_X[1]],
                mut_X[0],
                mut_X[1]+1,

                me_nature
                )

            try:
                series[sub_series] += 1
            except KeyError:
                series[sub_series] = 1

    if count in [total_variants//(100/i) for i in range(5,101,5)]:
        print(f'{round(100*count/total_variants,0)}% variants analysed')

data_keys = list(data.keys())
for key in series.keys():
    for i in range(len(key)):
        data[data_keys[i]].append(key[i])
    data['Count'].append(series[key])

df = pd.DataFrame(data)
df.to_csv(folder+'/Complete epistasis data - All.csv',index = False)

# Functional variants
print('Checking functional variants')

data = {
    'mut A bg':[],
    'mut A result':[],
    'mut A locus':[],
    
    'mut B bg':[],
    'mut B result':[],
    'mut B locus':[],

    'epistasis on bg':[],

    'mut X bg':[],
    'mut X result':[],
    'mut X locus':[],

    'epistasis on mut':[],

    'Count':[]
    }

series = {}

errors = set()
count = 0
total_variants = 4**9
for variant in get_variants(9):
    count += 1
    
    try:
        if fitness_data[variant] <= threshold:

            if count in [total_variants//(100/i) for i in range(5,101,5)]:
                print(f'{round(100*count/total_variants,0)}% variants analysed')

            continue
        
    except KeyError:
        continue

    for mut_pair in generate_mutations(2):
        mut_A = mut_pair[0]
        mut_B = mut_pair[1]

        if not (mutation_feasibility(variant,mut_A) and \
                mutation_feasibility(variant,mut_B)):
            continue

        try:
            mut_bA = get_mutant(variant,mut_A)
            mut_bB = get_mutant(variant,mut_B)

            be_nature = check_epistasis_nature(variant,mut_pair)['Nature']
            
        except KeyError:
            continue

        for mutation in generate_mutations(1):
            mut_X = mutation[0]

            if mut_X[1] in [mut_A[1],mut_B[1]] or \
               not mutation_feasibility(variant,mut_X):
                continue

            try:
                m = get_mutant(variant,mut_X)

                me_nature = check_epistasis_nature(m,mut_pair)['Nature']
                
            except KeyError:
                continue

            sub_series = (
                
                variant[mut_A[1]],
                mut_A[0],
                mut_A[1]+1,

                variant[mut_B[1]],
                mut_B[0],
                mut_B[1]+1,

                be_nature,

                variant[mut_X[1]],
                mut_X[0],
                mut_X[1]+1,

                me_nature
                )

            try:
                series[sub_series] += 1
            except KeyError:
                series[sub_series] = 1

    if count in [total_variants//(100/i) for i in range(5,101,5)]:
        print(f'{round(100*count/total_variants,0)}% variants analysed')

data_keys = list(data.keys())
for key in series.keys():
    for i in range(len(key)):
        data[data_keys[i]].append(key[i])
    data['Count'].append(series[key])

df = pd.DataFrame(data)
df.to_csv(folder+'/Complete epistasis data - Functional.csv',index = False)

# Non Functional variants
print('Checking non functional variants')

data = {
    'mut A bg':[],
    'mut A result':[],
    'mut A locus':[],
    
    'mut B bg':[],
    'mut B result':[],
    'mut B locus':[],

    'epistasis on bg':[],

    'mut X bg':[],
    'mut X result':[],
    'mut X locus':[],

    'epistasis on mut':[],

    'Count':[]
    }

series = {}

errors = set()
count = 0
total_variants = 4**9
for variant in get_variants(9):
    count += 1
    
    try:
        if fitness_data[variant] >= threshold:

            if count in [total_variants//(100/i) for i in range(5,101,5)]:
                print(f'{round(100*count/total_variants,0)}% variants analysed')

            continue
        
    except KeyError:
        continue

    for mut_pair in generate_mutations(2):
        mut_A = mut_pair[0]
        mut_B = mut_pair[1]

        if not (mutation_feasibility(variant,mut_A) and \
                mutation_feasibility(variant,mut_B)):
            continue

        try:
            mut_bA = get_mutant(variant,mut_A)
            mut_bB = get_mutant(variant,mut_B)

            be_nature = check_epistasis_nature(variant,mut_pair)['Nature']
            
        except KeyError:
            continue

        for mutation in generate_mutations(1):
            mut_X = mutation[0]

            if mut_X[1] in [mut_A[1],mut_B[1]] or \
               not mutation_feasibility(variant,mut_X):
                continue

            try:
                m = get_mutant(variant,mut_X)

                me_nature = check_epistasis_nature(m,mut_pair)['Nature']
                
            except KeyError:
                continue

            sub_series = (
                
                variant[mut_A[1]],
                mut_A[0],
                mut_A[1]+1,

                variant[mut_B[1]],
                mut_B[0],
                mut_B[1]+1,

                be_nature,

                variant[mut_X[1]],
                mut_X[0],
                mut_X[1]+1,

                me_nature
                )

            try:
                series[sub_series] += 1
            except KeyError:
                series[sub_series] = 1

    if count in [total_variants//(100/i) for i in range(5,101,5)]:
        print(f'{round(100*count/total_variants,0)}% variants analysed')

data_keys = list(data.keys())
for key in series.keys():
    for i in range(len(key)):
        data[data_keys[i]].append(key[i])
    data['Count'].append(series[key])

df = pd.DataFrame(data)
df.to_csv(folder+'/Complete epistasis data - Non Functional.csv',index = False)
