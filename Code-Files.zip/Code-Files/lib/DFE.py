from _DFE import *
from _mutation_effect import *

genotype_bins = dfe_bins(list(fitness_data.values()),list(fitness_data.keys()),
                         bin_size=0.05)

plot_data = {}
test_data = {}

## Splitting data: 90% genotypes will be used to plot the DFE
## and rest 10% will be used to perform stat tests

for genes in genotype_bins.values():

    try:
        pg_fitness,tg_fitness,\
        pg,tg = sklearn.model_selection.train_test_split([fitness_data[i] for i in genes],
                                                         genes,
                                                         test_size = 0.1)
    except ValueError:
        assert len(genes)<2
        pg_fitness = tg_fitness = [fitness_data[i] for i in genes]
        pg = tg = genes
        
    for i in range(len(pg)):
        plot_data[pg[i]] = pg_fitness[i]

    for i in range(len(tg)):
        test_data[tg[i]] = tg_fitness[i]

total_mutations = len(generate_mutations(1))
count = 0
# Plot data

all_data = {
    'Background Fitness':[],
    'Mutant Fitness':[],
    'SC':[]
    }
fun_data = {
    'Background Fitness':[],
    'Mutant Fitness':[],
    'SC':[]
    }
nf_data = {
    'Background Fitness':[],
    'Mutant Fitness':[],
    'SC':[]
    }

path = '../DFE - plot data/'

for mutation in generate_mutations(1):
    
    data = study_mutation(mutation,
                          background_status = 'all',
                          save_data = False,
                          consider_threshold = False,
                          fitness = plot_data)
    
    fun = study_mutation(mutation,
                          background_status = 'functional',
                          save_data = False,
                          consider_threshold = False,
                         fitness = plot_data)
    
    nf = study_mutation(mutation,
                          background_status = 'non functional',
                          save_data = False,
                          consider_threshold = False,
                        fitness = plot_data)

    for key in all_data.keys():
        
        all_data[key]+=data[key]
        fun_data[key]+=fun[key]
        nf_data[key]+=nf[key]
        
    count += 1
    if count in [total_mutations//(100/i) for i in range(10,101,10)]:
        print(f'{round(100*count/total_mutations,0)}% mutations checked on plot data')

all_df = pd.DataFrame(all_data)
all_df = all_df.sort_values(by = 'Background Fitness')
all_df.to_csv(f'{path}All compiled data.csv',index = False)

print(f'Data length: {len(all_df)}')

fun_df = pd.DataFrame(fun_data)
fun_df = fun_df.sort_values(by = 'Background Fitness')
fun_df.to_csv(f'{path}Functional compiled data.csv',index = False)

nf_df = pd.DataFrame(nf_data)
nf_df = nf_df.sort_values(by = 'Background Fitness')
nf_df.to_csv(f'{path}Non functional compiled data.csv',index = False)

bin_values = dfe_bins(fun_df['SC'],fun_df['SC'],bin_size = 0.01)
bin_values = list(bin_values.keys())
bin_values.sort()

all_df = pd.read_csv(f'{path}All compiled data.csv')
fun_df = pd.read_csv(f'{path}Functional compiled data.csv')
nf_df = pd.read_csv(f'{path}Non Functional compiled data.csv')

# Functional Probability Distributions
bins = dfe_bins(fun_df['Background Fitness'],fun_df['SC'],
                bin_size=0.05)
bin_values = list(bins.keys())
bin_values.sort()

for val in bin_values:
    data = bin_data(bins[val],bin_size=0.01,
                    max_preset = max(fun_df['SC'].values),
                    min_preset = min(fun_df['SC'].values))
    norm_coeff = sum(list(data.values()))*0.01
    prob_dist = {i:data[i]/norm_coeff for i in data.keys()}
    
    dfe_df = pd.DataFrame(data = {'SC':prob_dist.keys(),'PDF':prob_dist.values()}).sort_values(by = 'SC')
    dfe_df.to_csv(f'{path}Probability Distributions - functional/BF {val}.csv',
                  index = False)

# Non Functional Probability Distributions
bins = dfe_bins(nf_df['Background Fitness'],nf_df['SC'],
                bin_size=0.05)
bin_values = list(bins.keys())
bin_values.sort()

for val in bin_values:
    data = bin_data(bins[val],bin_size=0.01,
                    max_preset = max(nf_df['SC'].values),
                    min_preset = min(nf_df['SC'].values))
    norm_coeff = sum(list(data.values()))*0.01
    prob_dist = {i:data[i]/norm_coeff for i in data.keys()}
    
    dfe_df = pd.DataFrame(data = {'SC':prob_dist.keys(),'PDF':prob_dist.values()}).sort_values(by = 'SC')
    dfe_df.to_csv(f'{path}Probability Distributions - non functional/BF {val}.csv',
                  index = False)

# All Probability Distributions
bins = dfe_bins(all_df['Background Fitness'],all_df['SC'],
                bin_size=0.05)
bin_values = list(bins.keys())
bin_values.sort()

for val in bin_values:
    data = bin_data(bins[val],bin_size=0.01,
                    max_preset = max(all_df['SC'].values),
                    min_preset = min(all_df['SC'].values))
    norm_coeff = sum(list(data.values()))*0.01
    prob_dist = {i:data[i]/norm_coeff for i in data.keys()}
    
    dfe_df = pd.DataFrame(data = {'SC':prob_dist.keys(),'PDF':prob_dist.values()}).sort_values(by = 'SC')
    dfe_df.to_csv(f'{path}Probability Distributions - all/BF {val}.csv',
                  index = False)

# Test data

path = '../DFE - test data/'

all_df = pd.DataFrame({'Genotype':test_data.keys(),'Fitness':test_data.values()})
all_df = all_df.sort_values(by = 'Fitness')
all_df.to_csv(f'{path}Test genotypes data.csv',index = False)
