import os

# Beta lactamase analysis

try:
    os.mkdir('../Beta lactamase')
except FileExistsError:
    True

# DFE distribution design

try:
    os.mkdir('../DFE - plot data')
except FileExistsError:
    True

try:
    os.mkdir('../DFE - plot data/Probability Distributions - all')
except FileExistsError:
    True

try:
    os.mkdir('../DFE - plot data/Probability Distributions - functional')
except FileExistsError:
    True

try:
    os.mkdir('../DFE - plot data/Probability Distributions - non functional')
except FileExistsError:
    True

# DFE distribution test

try:
    os.mkdir('../DFE - test data')
except FileExistsError:
    True

try:
    os.mkdir('../DFE - test data/KS test')
except FileExistsError:
    True

try:
    os.mkdir('../DFE - test data/MWU test')
except FileExistsError:
    True

# Epistasis and epistasis change analysis

try:
    os.mkdir('../Epistasis')
except FileExistsError:
    True

try:
    os.mkdir('../Epistasis/Detailed data - epistasis change')
except FileExistsError:
    True

# Fitness effect of individual mutations

try:
    os.mkdir('../Mutation effect - all points')
except FileExistsError:
    True

try:
    os.mkdir('../Mutation effect - all points/Expanded mutations - all (for linear regression)')
except FileExistsError:
    True

# Effect of mutation on evolvability

try:
    os.mkdir('../Mutation effect on evolvability')
except FileExistsError:
    True

try:
    os.mkdir('../Mutation effect on evolvability/all variants')
except FileExistsError:
    True

try:
    os.mkdir('../Mutation effect on evolvability/functional variants')
except FileExistsError:
    True

try:
    os.mkdir('../Mutation effect on evolvability/non functional variants')
except FileExistsError:
    True

# Accessibility of highest peak

try:
    os.mkdir('../Peak Accessibility')
except FileExistsError:
    True

# Number of peaks in each size landscape

try:
    os.mkdir('../Peak count - all points')
except FileExistsError:
    True

try:
    os.mkdir('../Peak count - all points/Detailed data')
except FileExistsError:
    True

try:
    os.mkdir('../Peak count - functional')
except FileExistsError:
    True

try:
    os.mkdir('../Peak count - functional/Detailed data')
except FileExistsError:
    True

try:
    os.mkdir('../Peak Probability - all points')
except FileExistsError:
    True

try:
    os.mkdir('../Peak Probability - all points/Detailed data')
except FileExistsError:
    True

try:
    os.mkdir('../Peak Probability - functional')
except FileExistsError:
    True

try:
    os.mkdir('../Peak Probability - functional/Detailed data')
except FileExistsError:
    True

# Plots folder

try:
    os.mkdir('../Plots')
except FileExistsError:
    True

try:
    os.mkdir('../Plots/Beta lactamase')
except FileExistsError:
    True

try:
    os.mkdir('../Plots/DFE')
except FileExistsError:
    True

try:
    os.mkdir('../Plots/Epistasis change locus')
except FileExistsError:
    True

try:
    os.mkdir('../Plots/Mutation effect - all points')
except FileExistsError:
    True

try:
    os.mkdir('../Plots/Mutation effect on evolvability')
except FileExistsError:
    True

try:
    os.mkdir('../Plots/Peak Accessibility')
except FileExistsError:
    True

try:
    os.mkdir('../Plots/Peak Probability - all points')
except FileExistsError:
    True

try:
    os.mkdir('../Plots/Peak Probability - functional')
except FileExistsError:
    True

try:
    os.mkdir('../Plots/Peak count - all points')
except FileExistsError:
    True

try:
    os.mkdir('../Plots/Peak count - functional')
except FileExistsError:
    True
